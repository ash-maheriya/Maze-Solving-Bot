/*
 Ashbot: Arduino robot movements library.
 */

#include "Arduino.h"
#include "Ashbot.h"

// constructor
Ashbot::Ashbot(void) {
    LPIN = 12;
    RPIN = 11;
    LCENTER = 1496;
    RCENTER = 1498;
    L30_FW = 49;
    R30_FW = 48;
    L12_FW = 19;
    R12_FW = 17;
    L30_BK = 46;
    R30_BK = 50;
    L12_BK = 18;
    R12_BK = 20;
}

void Ashbot::detachServos(void) {
  servoLeft.detach();                 // Attach left signal to pin for left servo
  servoRight.detach();                   // Attach left signal to pin for left servo
}

void Ashbot::attachServos(void) {
  servoLeft.writeMicroseconds(LCENTER);
  servoRight.writeMicroseconds(RCENTER);
  servoLeft.attach(LPIN);                 // Attach left signal to pin for left servo
  servoRight.attach(RPIN);                   // Attach left signal to pin for left servo
}

void Ashbot::goForward(int cm) {
  double d;
  d = (1000.0 * (((double)cm)-0.8))/10.15;

  servoLeft.writeMicroseconds(LCENTER + L30_FW);
  servoRight.writeMicroseconds(RCENTER - R30_FW);
//  servoLeft.writeMicroseconds(LCENTER + L12_FW);
//  servoRight.writeMicroseconds(RCENTER - R12_FW);
  delay((int)d);
//  servoLeft.writeMicroseconds(LCENTER);
//  servoRight.writeMicroseconds(RCENTER);
}  

void Ashbot::goBackward(int cm) {
  double d;
  d = (1000.0 * (((double)cm)-0.8))/10.15;

  servoLeft.writeMicroseconds(LCENTER - L30_BK);
  servoRight.writeMicroseconds(RCENTER + R30_BK);
//  servoLeft.writeMicroseconds(LCENTER - L12_BK);
//  servoRight.writeMicroseconds(RCENTER + R12_BK);
  delay((int)d);
//  servoLeft.writeMicroseconds(LCENTER);
//  servoRight.writeMicroseconds(RCENTER);
}  

// Turn Left (CCW)
void Ashbot::turnLeft(void) {
  servoLeft.writeMicroseconds(LCENTER - L12_BK);
  servoRight.writeMicroseconds(RCENTER - R12_FW);
  delay(2800);
  servoLeft.writeMicroseconds(LCENTER);
  servoRight.writeMicroseconds(RCENTER);
}  

// Turn Right (CW)
void Ashbot::turnRight(void) {
  servoLeft.writeMicroseconds(LCENTER + L12_FW);
  servoRight.writeMicroseconds(RCENTER + R12_BK);
  delay(2820);
  servoLeft.writeMicroseconds(LCENTER);
  servoRight.writeMicroseconds(RCENTER);
}


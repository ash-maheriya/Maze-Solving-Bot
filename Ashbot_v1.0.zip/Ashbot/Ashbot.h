/*
 Ashbot.h - Library for controlling Ashbot.
  Created by Ashbot, November 1, 2014.
  Released into the public domain.
*/
#ifndef Ashbot_h
#define Ashbot_h

#include "Arduino.h"
#include "Servo.h"      // Include servo library
 

class Ashbot
{
  public:
    Servo servoLeft;
    Servo servoRight;

    Ashbot(void);
    void detachServos();
    void attachServos();
    void goForward(int cm);
    void goBackward(int cm);
    void turnLeft();
    void turnRight();

  private:
    int LPIN;
    int RPIN;
    int LCENTER;                    // Calibrated for left servo
    int RCENTER;                    // Calibrated for right servo
    int L30_FW;                       // Change from center for Left  servo to get ~30RPM forward direction
    int R30_FW;                       // Change from center for Right servo to get ~30RPM forward direction
    int L12_FW;                       // Change from center for Left  servo to get ~12RPM forward direction
    int R12_FW;                       // Change from center for Right servo to get ~12RPM forward direction
    int L30_BK;                       // Change from center for Left  servo to get ~30RPM backward direction
    int R30_BK;                       // Change from center for Right servo to get ~30RPM backward direction
    int L12_BK;                       // Change from center for Left  servo to get ~12RPM backward direction
    int R12_BK;                       // Change from center for Right servo to get ~12RPM backward direction


};

#endif
